/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author vkrte_000
 */
@Entity
@Table(name = "pobocka")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Pobocka.findAll", query = "SELECT p FROM Pobocka p")
    , @NamedQuery(name = "Pobocka.findByPobockaId", query = "SELECT p FROM Pobocka p WHERE p.pobockaId = :pobockaId")
    , @NamedQuery(name = "Pobocka.findByAdresa", query = "SELECT p FROM Pobocka p WHERE p.adresa = :adresa")
    , @NamedQuery(name = "Pobocka.findByKapacita", query = "SELECT p FROM Pobocka p WHERE p.kapacita = :kapacita")
    , @NamedQuery(name = "Pobocka.findByZaplneni", query = "SELECT p FROM Pobocka p WHERE p.zaplneni = :zaplneni")})
public class Pobocka implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "pobocka_id")
    private Integer pobockaId;
    @Size(max = 255)
    @Column(name = "adresa")
    private String adresa;
    @Column(name = "kapacita")
    private Integer kapacita;
    @Column(name = "zaplneni")
    private Integer zaplneni;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "pobockaId")
    private List<Zamestnanec> zamestnanecList;

    public Pobocka() {
    }

    public Pobocka(Integer pobockaId) {
        this.pobockaId = pobockaId;
    }

    public Integer getPobockaId() {
        return pobockaId;
    }

    public void setPobockaId(Integer pobockaId) {
        this.pobockaId = pobockaId;
    }

    public String getAdresa() {
        return adresa;
    }

    public void setAdresa(String adresa) {
        this.adresa = adresa;
    }

    public Integer getKapacita() {
        return kapacita;
    }

    public void setKapacita(Integer kapacita) {
        this.kapacita = kapacita;
    }

    public Integer getZaplneni() {
        return zaplneni;
    }

    public void setZaplneni(Integer zaplneni) {
        this.zaplneni = zaplneni;
    }

    @XmlTransient
    public List<Zamestnanec> getZamestnanecList() {
        return zamestnanecList;
    }

    public void setZamestnanecList(List<Zamestnanec> zamestnanecList) {
        this.zamestnanecList = zamestnanecList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (pobockaId != null ? pobockaId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Pobocka)) {
            return false;
        }
        Pobocka other = (Pobocka) object;
        if ((this.pobockaId == null && other.pobockaId != null) || (this.pobockaId != null && !this.pobockaId.equals(other.pobockaId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Pobocka[ pobockaId=" + pobockaId + " ]";
    }
    
}
