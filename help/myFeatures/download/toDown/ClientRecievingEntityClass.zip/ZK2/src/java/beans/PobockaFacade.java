/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beans;

import entities.Pobocka;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author vkrte_000
 */
@Stateless
public class PobockaFacade extends AbstractFacade<Pobocka> {

    @PersistenceContext(unitName = "ZK2PU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public PobockaFacade() {
        super(Pobocka.class);
    }
    
}
