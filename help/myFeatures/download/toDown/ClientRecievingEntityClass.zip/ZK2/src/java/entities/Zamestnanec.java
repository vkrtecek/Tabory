/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author vkrte_000
 */
@Entity
@Table(name = "zamestnanec")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Zamestnanec.findAll", query = "SELECT z FROM Zamestnanec z")
    , @NamedQuery(name = "Zamestnanec.findByRodneCislo", query = "SELECT z FROM Zamestnanec z WHERE z.rodneCislo = :rodneCislo")
    , @NamedQuery(name = "Zamestnanec.findByJmeno", query = "SELECT z FROM Zamestnanec z WHERE z.jmeno = :jmeno")
    , @NamedQuery(name = "Zamestnanec.findByPrijmeni", query = "SELECT z FROM Zamestnanec z WHERE z.prijmeni = :prijmeni")
    , @NamedQuery(name = "Zamestnanec.findByAdresa", query = "SELECT z FROM Zamestnanec z WHERE z.adresa = :adresa")
    , @NamedQuery(name = "Zamestnanec.findByPlat", query = "SELECT z FROM Zamestnanec z WHERE z.plat = :plat")
    , @NamedQuery(name = "Zamestnanec.findByZamestnanyOd", query = "SELECT z FROM Zamestnanec z WHERE z.zamestnanyOd = :zamestnanyOd")
    , @NamedQuery(name = "Zamestnanec.findByPujcenychKol", query = "SELECT z FROM Zamestnanec z WHERE z.pujcenychKol = :pujcenychKol")
    , @NamedQuery(name = "Zamestnanec.findByZamestnancemMesice", query = "SELECT z FROM Zamestnanec z WHERE z.zamestnancemMesice = :zamestnancemMesice")})
public class Zamestnanec implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "rodne_cislo")
    private Integer rodneCislo;
    @Size(max = 255)
    @Column(name = "jmeno")
    private String jmeno;
    @Size(max = 255)
    @Column(name = "prijmeni")
    private String prijmeni;
    @Size(max = 255)
    @Column(name = "adresa")
    private String adresa;
    @Column(name = "plat")
    private Integer plat;
    @Column(name = "zamestnany_od")
    private Integer zamestnanyOd;
    @Column(name = "pujcenych_kol")
    private Integer pujcenychKol;
    @Column(name = "zamestnancem_mesice")
    private Integer zamestnancemMesice;
    @JoinColumn(name = "pobocka_id", referencedColumnName = "pobocka_id")
    @ManyToOne(optional = false)
    private Pobocka pobockaId;

    public Zamestnanec() {
    }

    public Zamestnanec(Integer rodneCislo) {
        this.rodneCislo = rodneCislo;
    }

    public Integer getRodneCislo() {
        return rodneCislo;
    }

    public void setRodneCislo(Integer rodneCislo) {
        this.rodneCislo = rodneCislo;
    }

    public String getJmeno() {
        return jmeno;
    }

    public void setJmeno(String jmeno) {
        this.jmeno = jmeno;
    }

    public String getPrijmeni() {
        return prijmeni;
    }

    public void setPrijmeni(String prijmeni) {
        this.prijmeni = prijmeni;
    }

    public String getAdresa() {
        return adresa;
    }

    public void setAdresa(String adresa) {
        this.adresa = adresa;
    }

    public Integer getPlat() {
        return plat;
    }

    public void setPlat(Integer plat) {
        this.plat = plat;
    }

    public Integer getZamestnanyOd() {
        return zamestnanyOd;
    }

    public void setZamestnanyOd(Integer zamestnanyOd) {
        this.zamestnanyOd = zamestnanyOd;
    }

    public Integer getPujcenychKol() {
        return pujcenychKol;
    }

    public void setPujcenychKol(Integer pujcenychKol) {
        this.pujcenychKol = pujcenychKol;
    }

    public Integer getZamestnancemMesice() {
        return zamestnancemMesice;
    }

    public void setZamestnancemMesice(Integer zamestnancemMesice) {
        this.zamestnancemMesice = zamestnancemMesice;
    }

    public Pobocka getPobockaId() {
        return pobockaId;
    }

    public void setPobockaId(Pobocka pobockaId) {
        this.pobockaId = pobockaId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (rodneCislo != null ? rodneCislo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Zamestnanec)) {
            return false;
        }
        Zamestnanec other = (Zamestnanec) object;
        if ((this.rodneCislo == null && other.rodneCislo != null) || (this.rodneCislo != null && !this.rodneCislo.equals(other.rodneCislo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Zamestnanec[ rodneCislo=" + rodneCislo + " ]";
    }
    
}
