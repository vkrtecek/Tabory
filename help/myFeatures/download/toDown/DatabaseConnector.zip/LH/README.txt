/************************************************/
Made by:	Vojtech Stuchlik
Date:		2017-01-09
/***********************************************/

1.	COPY+PASTE database.sql content into your
	database and run this sql command

2.	execute LH.jar